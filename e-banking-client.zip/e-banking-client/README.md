#To run
npm i
npm start