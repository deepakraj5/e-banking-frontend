import React from 'react'

class Service2 extends React.Component{
    render(){
        return(
            <div className="container jumbotron shadow bg-white rounded">
                <h2>Service2</h2>
            </div>
        );
    }
}

export default Service2