import React from 'react'

class ContactUS extends React.Component{
    render(){
        return(
            <div className="container jumbotron shadow bg-white rounded">
               <h2>ContactUS</h2>
            </div>
        );
    }
}

export default ContactUS