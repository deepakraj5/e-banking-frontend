import React from 'react'

class Careers extends React.Component{
    render(){
        return(
            <div className="container jumbotron shadow bg-white rounded">
               <h2>Careers</h2>
            </div>
        );
    }
}

export default Careers