import React from 'react'

class Loan extends React.Component{
    render(){
        return(
            <div className="container jumbotron shadow bg-white rounded">
               <h2>Loan</h2>
            </div>
        );
    }
}

export default Loan