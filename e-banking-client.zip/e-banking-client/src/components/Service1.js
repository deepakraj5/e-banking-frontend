import React from 'react'

class Service1 extends React.Component{
    render(){
        return(
            <div className="container jumbotron shadow bg-white rounded">
                <h2>Service1</h2>
            </div>
        );
    }
}

export default Service1